package dao;

import static utils.HibernateUtils.getSf;

import org.hibernate.Session;
import org.hibernate.Transaction;

import pojos.Course;
import pojos.Student;

public class StudentDaoImpl implements IStudentDao {

	@Override
	public String admitStudent(Student s, String courseName) {
		String jpql = "select c from Course c where c.name=:nm";
		String mesg = "Student admission failed";
		// Session
		Session hs = getSf().getCurrentSession();
		Transaction tx = hs.beginTransaction();
		try {
			Course c = hs.createQuery(jpql, Course.class).setParameter("nm", courseName).getSingleResult();
			// c --PERSISTENT
			c.addStudent(s);// helper method
			tx.commit();// dirty chking -- inserts a rec in students table & assighn FK
			mesg = "Student admitted to " + courseName + " course ";
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}

		return mesg;
	}

	@Override
	public String cancelStudentAdmission(int courseId, int studentId) {
		String mesg = "cancelling admission failed";
		// Session
		Session hs = getSf().getCurrentSession();
		Transaction tx = hs.beginTransaction();
		try {
			// get course dtls
			Course c = hs.get(Course.class, courseId);
			// get student dtls
			Student s = hs.get(Student.class, studentId);
			if (c != null && s != null)
				c.removeStudent(s);
			tx.commit();// dirty chking -- 
			mesg = "Student admission cancelled";
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return mesg;

	}

}
