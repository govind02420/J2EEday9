package dao;

import pojos.Course;

public interface ICourseDao {
	String launchCourse(Course c);
	Course getCourseDetails(String cName);
	Course getCourseNStudentDetails(String cName);
	Course getCourseNStudentDetails2(String cName);
}
