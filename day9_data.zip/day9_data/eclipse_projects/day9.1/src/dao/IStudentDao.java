package dao;

import pojos.Student;

public interface IStudentDao {
	String admitStudent(Student s,String courseName);
	String cancelStudentAdmission(int courseId,int studentId);
}
