package dao;

import pojos.Course;
import org.hibernate.*;
import static utils.HibernateUtils.*;

public class CourseDaoImpl implements ICourseDao {

	@Override
	public String launchCourse(Course c) {
		String mesg = "Launching course failed";
		// Session
		Session hs = getSf().getCurrentSession();
		Transaction tx = hs.beginTransaction();
		try {
			/*
			 * System.out.println(c.getId()); c.setId(123);
			 */ hs.persist(c);// persistent
			tx.commit();
			mesg = "Launched course with ID =" + c.getId();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}

		return mesg;
	}

	@Override
	public Course getCourseDetails(String cName) {
		Course c = null;
		String jpql = "select c from Course c where c.name=:nm";
		// session
		Session session = getSf().getCurrentSession();
		Transaction tx = session.beginTransaction();
		try {
			c = session.createQuery(jpql, Course.class).setParameter("nm", cName).getSingleResult();
			// c --PERSISTENT

			tx.commit();// session closed
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return c;// c-- DETACHED
	}

	@Override
	public Course getCourseNStudentDetails(String cName) {
		Course c = null;
		String jpql = "select c from Course c where c.name=:nm";
		// session
		Session session = getSf().getCurrentSession();
		Transaction tx = session.beginTransaction();
		try {
			c = session.createQuery(jpql, Course.class).setParameter("nm", cName).getSingleResult();
			// c --PERSISTENT
			// access the size of collection --- hib is forced to fire another select query
			c.getStudents().size();
			tx.commit();// session closed
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return c;// c-- DETACHED

	}

	@Override
	public Course getCourseNStudentDetails2(String cName) {
		Course c = null;
		String jpql = "select c from Course c left outer join fetch c.students where c.name=:nm";
		// session
		Session session = getSf().getCurrentSession();
		Transaction tx = session.beginTransaction();
		try {
			c = session.createQuery(jpql, Course.class).setParameter("nm", cName).getSingleResult();
			tx.commit();// session closed
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return c;// c-- DETACHED

	}

}
