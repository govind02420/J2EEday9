package pojos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "students")
public class Student {
	private Integer studentId;
	private String name, email;
	// Student HAS-A Course
	private Course selectedCourse;
	// Stduent HAS-A Address --one to one mapping between 2 entites
	private Address adr;
	// one-to-one asso between entity n embeddable composite value type(comp)
	private AdharCard card;
	// one to many asso between entity n basic value type
	private List<String> hobbies = new ArrayList<>();
	// one to many asso between entity n embeddable value type
	private List<EduQualification> qualifications = new ArrayList<>();

	public Student() {
		// TODO Auto-generated constructor stub
	}

	public Student(String name, String email) {
		super();
		this.name = name;
		this.email = email;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "sid")
	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	@Column(length = 20)
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Column(length = 20, unique = true)
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@ManyToOne
	@JoinColumn(name = "course_id")
	public Course getSelectedCourse() {
		return selectedCourse;
	}

	public void setSelectedCourse(Course selectedCourse) {
		this.selectedCourse = selectedCourse;
	}

	@OneToOne(mappedBy = "stud", cascade = CascadeType.ALL)
	public Address getAdr() {
		return adr;
	}

	public void setAdr(Address adr) {
		this.adr = adr;
	}

	// collection of basic type
	@ElementCollection // mandatory
	@CollectionTable(name = "student_hobbies", joinColumns = @JoinColumn(name = "sid"))
	@Column(name = "hobby", length = 20)
	public List<String> getHobbies() {
		return hobbies;
	}

	public void setHobbies(List<String> hobbies) {
		this.hobbies = hobbies;
	}

	@ElementCollection
	@CollectionTable(name = "stud_quals", joinColumns = @JoinColumn(name = "sid"))
	public List<EduQualification> getQualifications() {
		return qualifications;
	}

	public void setQualifications(List<EduQualification> qualifications) {
		this.qualifications = qualifications;
	}

	@Embedded // optional
	public AdharCard getCard() {
		return card;
	}

	public void setCard(AdharCard card) {
		this.card = card;
	}

	// convenience methods
	public void addAddress(Address a) {
		// student ---> address
		this.adr = a;
		a.setStud(this);// address ---> stduent
	}

	public void removeAddress(Address a) {
		adr = null;
		a.setStud(null);
	}

	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", name=" + name + ", email=" + email + "]";
	}

}
