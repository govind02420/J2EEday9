package pojos;
import javax.persistence.*;

@Embeddable
public class EduQualification {
	private String type;
	private int year;
	private double gpa;
	public EduQualification() {
		// TODO Auto-generated constructor stub
	}
	public EduQualification(String type, int year, double gpa) {
		super();
		this.type = type;
		this.year = year;
		this.gpa = gpa;
	}
	@Column(name="edu_type",length=20)
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public double getGpa() {
		return gpa;
	}
	public void setGpa(double gpa) {
		this.gpa = gpa;
	}
	@Override
	public String toString() {
		return "EduQualification [type=" + type + ", year=" + year + ", gpa=" + gpa + "]";
	}
	

}
