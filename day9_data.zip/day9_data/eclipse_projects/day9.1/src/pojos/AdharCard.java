package pojos;

import java.time.LocalDate;
import javax.persistence.*;

@Embeddable //mandatory
public class AdharCard {
	private String cardNumber;
	private LocalDate createdOn;
	
	public AdharCard() {
		// TODO Auto-generated constructor stub
	}
	public AdharCard(String cardNumber, LocalDate createdOn) {
		super();
		this.cardNumber = cardNumber;
		this.createdOn = createdOn;
	}
	@Column(name="card_num",unique=true,length=20)
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	@Column(name="created_on")
	public LocalDate getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(LocalDate createdOn) {
		this.createdOn = createdOn;
	}
	@Override
	public String toString() {
		return "AdharCard [cardNumber=" + cardNumber + ", createdOn=" + createdOn + "]";
	}
	

}
