package tester;

import static utils.HibernateUtils.getSf;

import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.CourseDaoImpl;
import pojos.Course;
import pojos.Student;

public class GetCourseAndStudentDetails {

	public static void main(String[] args) {
		try (SessionFactory sf = getSf();Scanner sc=new Scanner(System.in)) {
			System.out.println("Enter course name");
			CourseDaoImpl dao=new CourseDaoImpl();
			Course c=dao.getCourseNStudentDetails(sc.next());
			System.out.println("Course dtls "+c);
			System.out.println("Students : ");
			for(Student s : c.getStudents())
				System.out.println(s);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
