package tester;

import org.hibernate.*;

import dao.StudentDaoImpl;
import pojos.Address;
import pojos.AdharCard;
import pojos.EduQualification;
import pojos.Student;

import static utils.HibernateUtils.getSf;

import java.time.LocalDate;
import java.util.Scanner;

public class StudentAdmission2 {

	public static void main(String[] args) {
		try (SessionFactory sf = getSf(); Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter course name");
			String cName = sc.next();
			System.out.println("Enter student dtls nm email");
			Student s = new Student(sc.next(), sc.next());
			System.out.println("Enter address details city st co cell");
			Address a = new Address(sc.next(), sc.next(), sc.next(), sc.next());
			// establish bi dir asso between student n addres
			s.addAddress(a);
			System.out.println("Enter adhar card no n date(yr-mon-day)");
			AdharCard card = new AdharCard(sc.next(), LocalDate.parse(sc.next()));
			// link adhar card to student
			s.setCard(card);
			// hobbies
			System.out.println("Enter 3 hobbies");
			s.getHobbies().add(sc.next());
			s.getHobbies().add(sc.next());
			s.getHobbies().add(sc.next());
			for (int i = 0; i < 2; i++) {
				System.out.println("Enter qualification dtls type yr gpa");
				s.getQualifications().add(new EduQualification(sc.next(), sc.nextInt(), sc.nextDouble()));
			}
			// dao
			StudentDaoImpl dao = new StudentDaoImpl();
			System.out.println(dao.admitStudent(s, cName));

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
