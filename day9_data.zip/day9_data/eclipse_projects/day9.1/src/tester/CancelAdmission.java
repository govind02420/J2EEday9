package tester;

import org.hibernate.*;

import dao.StudentDaoImpl;
import pojos.Address;
import pojos.Student;

import static utils.HibernateUtils.getSf;

import java.util.Scanner;

public class CancelAdmission {

	public static void main(String[] args) {
		try (SessionFactory sf = getSf(); Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter course n student id");
			// dao
			StudentDaoImpl dao = new StudentDaoImpl();
			System.out.println(dao.cancelStudentAdmission(sc.nextInt(), sc.nextInt()));

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
